<footer>    
    <h2> Contact Me </h2>
    <span>
        If you have any questions, comments, or concerns, please feel free to reach out to me at: 
        <a href="mailto:jht3250@rit.edu">jht3250@rit.edu</a>
    </span>
</footer>