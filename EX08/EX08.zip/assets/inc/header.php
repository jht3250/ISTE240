<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $page;?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo $path;?>assets/css/pizza.css" />
	<script type="text/javascript" src="<?php echo $path;?>assets/script/pizza.js"></script>
</head>
<body>

	<div id="wrapper">

	<h1>Eat more Pizza!</h1>
	<p><img src="assets/img/hotpizza.png"></p>